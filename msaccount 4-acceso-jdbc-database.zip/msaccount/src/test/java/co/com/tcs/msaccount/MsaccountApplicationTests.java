package co.com.tcs.msaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsaccountApplicationTests {

	@Test
	void contextLoads() {
	}

}

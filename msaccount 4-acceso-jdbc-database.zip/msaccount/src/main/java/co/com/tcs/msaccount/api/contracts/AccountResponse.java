package co.com.tcs.msaccount.api.contracts;

import co.com.tcs.msaccount.model.Account;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AccountResponse {
    private Account account;
    private int errorCode;
    private String errorDescription;
}

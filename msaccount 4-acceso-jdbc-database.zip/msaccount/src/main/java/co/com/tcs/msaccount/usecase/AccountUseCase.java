package co.com.tcs.msaccount.usecase;

import co.com.tcs.msaccount.api.contracts.AccountResponse;
import co.com.tcs.msaccount.infraestructure.adapter.AccountAdapter;
import co.com.tcs.msaccount.model.Account;
import lombok.Builder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Builder
public class AccountUseCase {
    // Get By ID
    public ResponseEntity<AccountResponse> queryAccountById(String type, long number){
        var codeHttp = HttpStatus.OK;
        var response =
                AccountResponse
                .builder()
                .errorCode(0)
                .errorDescription("Successfully")
                .build();
        var account = Account.builder().build();
        if (type == null){
            response.setErrorCode(1);
            codeHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Type is null");
        } else if (type.equalsIgnoreCase("")){
            response.setErrorCode(2);
            codeHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Type no data");
        } else if(number == 0){
            response.setErrorCode(3);
            codeHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Number no data");
        } else {
            account = AccountAdapter.builder().build().getById(type, number);
            if (account == null){
                response.setErrorCode(4);
                codeHttp = HttpStatus.NO_CONTENT;
                response.setErrorDescription("Not account info");
            }
        }
        response.setAccount(account);
        return new ResponseEntity<AccountResponse>(response, codeHttp);
    }

    public ResponseEntity<List<Account>> queryAllAccount (){
        var codeHttp = HttpStatus.OK;
        var response = AccountAdapter.builder().build().getAll();
        return new ResponseEntity<List<Account>>(response, codeHttp);
    }
}

package co.com.tcs.msaccount.helper;

import co.com.tcs.msaccount.model.Account;

public class SampleInstance {
    public static void main(String[] args){
        var account = Account.builder()
                .type("CC")
                .number(1234)
                .build();
        String type = account.getType();
        account.getBalance();
        System.out.println("Account: " + account);
    }
}

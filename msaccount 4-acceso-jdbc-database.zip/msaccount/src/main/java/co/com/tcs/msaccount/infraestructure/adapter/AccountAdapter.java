package co.com.tcs.msaccount.infraestructure.adapter;

import co.com.tcs.msaccount.infraestructure.database.Database;
import co.com.tcs.msaccount.model.Account;
import co.com.tcs.msaccount.model.AccountGateway;
import lombok.Builder;
import lombok.SneakyThrows;

import java.util.ArrayList;
import java.util.List;

@Builder
public class AccountAdapter implements AccountGateway {
    @SneakyThrows
    @Override
    public Account getById(String type, long number) {
        // Ir por la info a la base de datos
        var database = Database.builder().build();
        database.createConnection();
        var conn = database.getConn();
        var sqlStmt = String.format("SELECT * FROM tbl_account WHERE type = '%s' AND number = %s", type, number);
        database.setPs(conn.prepareCall(sqlStmt));
        var rs = database.getPs().executeQuery();
        Account accountData = null;
        if (rs != null){
            if (rs.next()) {
                accountData = Account.builder().build();
                accountData.setType(rs.getString("type"));
                accountData.setNumber(rs.getLong("number"));
                accountData.setBalance(rs.getDouble("balance"));
            }
        }
        conn.close();
        return accountData;
    }

    @SneakyThrows
    @Override
    public List<Account> getAll() {
        // Ir por la info a la base de datos
        var database = Database.builder().build();
        database.createConnection();
        var conn = database.getConn();
        var sqlStmt = "SELECT * FROM tbl_account";
        database.setPs(conn.prepareCall(sqlStmt));
        var rs = database.getPs().executeQuery();
        List<Account> accountList = new ArrayList<>();
        Account accountData = null;
        if (rs != null){
            while (rs.next()) {
                accountData = Account.builder().build();
                accountData.setType(rs.getString("type"));
                accountData.setNumber(rs.getLong("number"));
                accountData.setBalance(rs.getDouble("balance"));
                accountList.add(accountData);
            }
        }
        conn.close();
        return accountList;
    }

    @Override
    public List<Account> getByType(String type) {
        return null;
    }

    @Override
    public boolean create(Account account) {
        return false;
    }

    @Override
    public boolean update(Account account) {
        return false;
    }

    @Override
    public boolean delete(String type, long number) {
        return false;
    }

    @Override
    public boolean deleteAll() {
        return false;
    }
}

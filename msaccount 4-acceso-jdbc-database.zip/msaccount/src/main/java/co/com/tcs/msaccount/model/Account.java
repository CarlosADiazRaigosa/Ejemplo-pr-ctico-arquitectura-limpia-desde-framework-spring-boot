package co.com.tcs.msaccount.model;

import lombok.*;

@Builder
@Data
public class Account {
    private String type;
    private long number;
    private double balance;
    private boolean state;
    private String dateCreation;
    private String userCreation;
}
